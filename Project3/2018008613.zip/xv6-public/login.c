#include "types.h"
#include "user.h"
#include "fcntl.h"

int main()
{
	while (1)
	{
		char username[17], password[17];
		
		printf(2, "LOG IN\n");
		printf(2, "username을 입력하세요 :");
		gets(username, 17);
		printf(2, "password를 입력하세요 :");
		gets(password, 17);
		for (int i = 0;i < 17;i++)
		{
			if (username[i] == '\n')
			{
				username[i] = '\0';
				break;
			}
		}
		for (int i = 0;i < 17;i++)
		{
			if (password[i] == '\n')
			{
				password[i] = '\0';
				break;
			}
		}
		int chk = chkLogin(username, password);
		if (chk)
		{
			printf(2, "login success!\n");
			setUsername(username);
			int chk_pid = fork();
			char *argv[] = { "sh", 0 };
			if (chk_pid == 0)
			{
				if (exec("sh", argv) == -1)
					printf(2, "exec failed\n");
			}
			wait();
		}
		else
			printf(2, "login failed\n");
	}
	return 0;
}
